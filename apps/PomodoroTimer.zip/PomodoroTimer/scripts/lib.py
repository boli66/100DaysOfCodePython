FONT = ("arial", 18, "bold")
CHECKMARK = "✓"
CHECKMARKFONT = ("arial", 20, "bold")
SECOND = 1000

PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"
WORK_MIN = 25
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20
PANDOROS = 4

def m_to_s(minutes):
    return minutes * 60