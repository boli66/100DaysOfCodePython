from tkinter import Button


class Reset(Button):
    pass
